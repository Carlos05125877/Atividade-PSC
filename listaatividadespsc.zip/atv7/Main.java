/*Escreva um programa que calcule os quadrados e cubos dos números de 0 a 10 e imprima os
valores resultantes formatados, conforme a tabela 3*/


public class Main
{
	public static void main(String[] args) {
	    Double quadrado0; 
	    Double quadrado1; 
	    Double quadrado2; 
	    Double quadrado3; 
	    Double quadrado4; 
	    Double quadrado5; 
	    Double quadrado6; 
	    Double quadrado7; 
	    Double quadrado8; 
	    Double quadrado9; 
	    Double quadrado10;
	    Double cubo0;
	    Double cubo1;
	    Double cubo2;
	    Double cubo3;
	    Double cubo4;
	    Double cubo5;
	    Double cubo6;
	    Double cubo7;
	    Double cubo8;
	    Double cubo9;
	    Double cubo10;
	    
	    quadrado0 = (Math.pow(0, 2));
	    quadrado1 = (Math.pow(1, 2));
	    quadrado2 = (Math.pow(2, 2));
	    quadrado3 = (Math.pow(3, 2));
	    quadrado4 = (Math.pow(4, 2));
	    quadrado5 = (Math.pow(5, 2));
	    quadrado6 = (Math.pow(6, 2));
	    quadrado7 = (Math.pow(7, 2));
	    quadrado8 = (Math.pow(8, 2));
	    quadrado9 = (Math.pow(9, 2));
	    quadrado10 = (Math.pow(10, 2));
	    cubo0 = (Math.pow(0, 3));
	    cubo1 = (Math.pow(1, 3));
	    cubo2 = (Math.pow(2, 3));
	    cubo3 = (Math.pow(3, 3));
	    cubo4 = (Math.pow(4, 3));
	    cubo5 = (Math.pow(5, 3));
	    cubo6 = (Math.pow(6, 3));
	    cubo7 = (Math.pow(7, 3));
	    cubo8 = (Math.pow(8, 3));
	    cubo9 = (Math.pow(9, 3));
	    cubo10 = (Math.pow(10, 3));
	    
	    
		System.out.println("Número " + "Quadrado " + "Cubo ");
		System.out.println(0 + "       " + quadrado0 + "      " + cubo0);
		System.out.println(1 + "       " + quadrado1 + "      " + cubo1);
		System.out.println(2 + "       " + quadrado2 + "      " + cubo2);
		System.out.println(3 + "       " + quadrado3 + "      " + cubo3);
		System.out.println(4 + "       " + quadrado4 + "     " + cubo4);
		System.out.println(5 + "       " + quadrado5 + "     " + cubo5);
		System.out.println(6 + "       " + quadrado6 + "     " + cubo6);
		System.out.println(7 + "       " + quadrado7 + "     " + cubo7);
		System.out.println(8 + "       " + quadrado8 + "     " + cubo8);
		System.out.println(9 + "       " + quadrado9 + "     " + cubo9);
		System.out.println(10 + "      " + quadrado10 + "    " + cubo10);
	}
}
